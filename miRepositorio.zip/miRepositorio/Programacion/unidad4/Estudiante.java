package unidad4;

public class Estudiante {
	static int num_estudiantes = 0;
	
	String nombre;
	private int edad;
	String direccion;
	
	Estudiante() {
		num_estudiantes++;
	}
	
	String dame_nombre() {
		return nombre;
	}
	
	static int dame_num_estudiantes() {
		return num_estudiantes;
	}
	
	int dame_edad() {
		return edad;
	}
}
