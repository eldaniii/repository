package unidad4;

public abstract class Perro extends Viviparo {
	private int patas;
	private boolean cola;
	private int numeroChip;
	
	Perro() {
		super();
	}
	
	@Override
	public void comunicarse() {
		System.out.println("Woof woof!");
	}
	
	public void olfatear() {
		System.out.println("Sniff sniff!");
	}

	public int getPatas() {
		return patas;
	}

	public void setPatas(int patas) {
		this.patas = patas;
	}

	public boolean isCola() {
		return cola;
	}

	public void setCola(boolean cola) {
		this.cola = cola;
	}

	public int getNumeroChip() {
		return numeroChip;
	}

	public void setNumeroChip(int numeroChip) {
		this.numeroChip = numeroChip;
	}
}
