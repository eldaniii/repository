package unidad4;

public abstract class Animal {
	private String nombre;
	private int edad;
	static int especimenes=0;
	
	Animal() {
		especimenes++;
	}
	
	public abstract void comunicarse();
	
	public abstract void reproducirse();
	
	public void muere() {
		System.out.println("He muerto.");
	}
	
	public static void getEspecimenes() {
		System.out.println("Especímenes creados: "+especimenes);
	}

	public static void setEspecimenes(int especimenes) {
		Animal.especimenes = especimenes;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
}
