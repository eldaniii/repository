package unidad4;

public abstract class Oviparo extends Animal {
	static int especimenes=0;
	
	Oviparo() {
		super();
		especimenes++;
	}
	
	public void reproducirse() {
		System.out.println("Reproduciendose (ovíparo)!");
	}

	public static void getVidas() {
		System.out.println("Ovíparos creados: "+especimenes);
	}
}
