package unidad4;

public abstract class Reptil extends Oviparo{
	
	Reptil() {
		super();
	}
	
}
