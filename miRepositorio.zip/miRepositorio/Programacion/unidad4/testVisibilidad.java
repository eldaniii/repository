package unidad4;

public class testVisibilidad {
	/*public class Vagon {
		int capacidadMax;
		int capacidadActual;
		String tipoMercancia;
		
		Vagon(){
			this.capacidadMax=5000;
			this.capacidadActual=0;
			this.tipoMercancia="Sin especificar.";
		}
		
		Vagon(int capacidadMax, int capacidadActual, String tipoMercancia){
			this.capacidadMax=capacidadMax;
			this.capacidadActual=capacidadActual;
			this.tipoMercancia=tipoMercancia;
		}
	}*/
}
