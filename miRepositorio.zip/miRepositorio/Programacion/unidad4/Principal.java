package unidad4;

import java.util.Scanner;

import unidad4.tarea1.CuentaCorriente;

public class Principal {
	public static void main(String[] args) {
		/*Scanner sc = new Scanner(System.in);
		
		Perro perro1 = new Perro();
		Perro perro2 = new Perro();
		Ave ave1 = new Ave();
		Pato pato1 = new Pato();
		
		perro1.setNombre("Scooby");
		perro1.setEdad(7);
		perro1.setNumeroChip(12321352);
		perro1.setCola(true);
		perro1.setPatas(4);
		perro1.reproducete();
		ave1.reproducete();
		
		ave1.setNombre("Pioli");
		ave1.setAlas(true);
		ave1.setEdad(4);
		ave1.setPatas(2);

		pato1.setNombre("Donald");
		
		
		Animal.getEspecimenes();
		Viviparo.getEspecimenes();
		
		Estudiante e1 = new Estudiante();
		Estudiante e2 = new Estudiante();
		Estudiante e3 = new Estudiante();
		
		System.out.println(e1.dame_nombre());
		System.out.println(e1.edad); //error: es private
		System.out.println(e1.dame_edad());
		
		System.out.println("# de estudiante: " + e1.num_estudiantes);
		System.out.println("# de estudiante: " + e2.num_estudiantes);
		System.out.println("# de estudiante: " + e3.num_estudiantes);
		System.out.println("# de estudiante: " + Estudiante.num_estudiantes);
		*/
		
		Serpiente serp1 = new Serpiente();
		Pato pato1 = new Pato();
		
		System.out.println(pato1.getClass().getSimpleName());
		pato1.setNombre("Lucas");
		pato1.comunicarse();
		pato1.hacerNido();
		pato1.reproducirse();
		
		System.out.println("-------------------");
		
		Serpiente.muestraEspecies();
		System.out.println(serp1.getClass().getSimpleName());
		serp1.setNombre("Cobry");
		serp1.comunicarse();
		serp1.reproducirse();
		//serp1.morder(Especies.COBRA);
	}
}
