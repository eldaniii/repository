package unidad4.tarea1;

public class Bombilla {
	private static boolean mainSwitch = true;
	private boolean singleSwitch;
	
	Bombilla() {
		this.singleSwitch = false;
	}
	
	public boolean isOn() {
		if (!mainSwitch || !singleSwitch) {
			return false;
		} else return true;
	}
	
	public void singleSwitchOn() {
		this.singleSwitch=true;
	}
	
	public void singleSwitchOff() {
		this.singleSwitch=false;
	}
	
	public static void blowFuses() {
		mainSwitch=false;
	}
	
	public static void repairFuses() {
		mainSwitch=true;
	}
	
	public static void main(String[] args) {
		Bombilla bombilla1 = new Bombilla();
	    Bombilla bombilla2 = new Bombilla();

	    bombilla1.singleSwitchOn();
	    bombilla2.singleSwitchOn();
	    
	    System.out.println("Encendemos la bombilla número 1 y 2:");
	    System.out.println("Bombilla 1: " + bombilla1.isOn());
	    System.out.println("Bombilla 2: " + bombilla2.isOn());
	    
	    System.out.println("--------------------------------------");

	    blowFuses();

	    System.out.println("Después de saltar fusibles:");
	    System.out.println("Bombilla 1: "+bombilla1.isOn());
	    System.out.println("Bombilla 2: "+bombilla2.isOn());
	    
	    System.out.println("--------------------------------------");
	    
	    repairFuses();

	    System.out.println("Después de reparar fusibles:");
	    System.out.println("Bombilla 1: "+bombilla1.isOn());
	    System.out.println("Bombilla 2: "+bombilla2.isOn());
	    
	    System.out.println("--------------------------------------");
	    
	    bombilla2.singleSwitchOff();
	    
	    System.out.println("Después de apagar la bombilla número 2:");
	    System.out.println("Bombilla 1: "+bombilla1.isOn());
	    System.out.println("Bombilla 2: "+bombilla2.isOn());
	}
}
