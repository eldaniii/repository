package unidad4.tarea1;

public class Banco {
	private String nombre;
	public double capital;
	public String direccion;
	
	Banco(String nombre) {
		this.nombre=nombre;
		this.capital=5200000;
		this.direccion="Sin dirección";
	}
	
	Banco(String nombre, double capital) {
		this.nombre=nombre;
		this.capital=capital;
		this.direccion="Sin dirección";
	}
	
	public double getCapital() {
		return capital;
	}

	public void setCapital(double capital) {
		this.capital = capital;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getNombre() {
		return nombre;
	}
}
