package unidad4.tarea1;

public interface Unidades {
	enum uLongitud{MM,CM,DM,M,DAM,HM,KM}
}
