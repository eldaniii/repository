package unidad4.tarea1;

public class Hora {
	private int hora;
	private int min;
	private int segundo;
	
	Hora(int hora, int min, int segundo){
		this.hora=hora;
		this.min=min;
		this.segundo=segundo;
	}
	
	public void sumarSegundos(int n) {
		System.out.println("Hora introducida: "+this.hora+"h"+this.min+"m"+this.segundo+"s"+"\n");
		
		int totalSegundos=(this.hora*3600)+(this.min*60)+this.segundo+n;
		this.hora=totalSegundos/3600;
		this.min=(totalSegundos%3600)/60;
		this.segundo=(totalSegundos%3600)%60;
		
		System.out.println("Hora introducida: "+this.hora+"h"+this.min+"m"+this.segundo+"s"+"\n");
	}
	
	public int getHora() {
		return hora;
	}
	public void setHora(int hora) {
		this.hora = hora;
	}
	public int getMin() {
		return min;
	}
	public void setMin(int min) {
		this.min = min;
	}
	public int getSegundo() {
		return segundo;
	}
	public void setSegundo(int segundo) {
		this.segundo = segundo;
	}
}