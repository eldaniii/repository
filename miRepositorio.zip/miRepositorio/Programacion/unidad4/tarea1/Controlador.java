package unidad4.tarea1;

public class Controlador {
	private double frecuencia;
	private final double frecuenciaMin=80.00;
	private final double frecuenciaMax=108.00;
	
	Controlador(){
		this.frecuencia=80.00;
	}
	
	Controlador(double frecuencia) {
		this.frecuencia=frecuencia;
	}
	
	public void display() {
		System.out.println("Frecuencia sintonizada: "+frecuencia+" Mhz");
	}
	
	public void subirFrecuencia() {
		this.frecuencia+=0.5;
		if (this.frecuencia>frecuenciaMax) this.frecuencia=frecuenciaMin;
	}
	
	public void bajarFrecuencia() {
		this.frecuencia-=0.5;
		if (this.frecuencia<frecuenciaMin) this.frecuencia=frecuenciaMax;
	}
	
	public static void main(String[] args) {
		Controlador controlador1 = new Controlador();
		
		controlador1.display();
		
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		controlador1.subirFrecuencia();
		
		controlador1.display();
		
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		
		controlador1.display();
		
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		controlador1.bajarFrecuencia();
		
		controlador1.display();
	}
}
