package unidad4.tarea1;

public class Personal {
	public class Maquinista {
		public String nombreCompleto;
		public String dni;
		public int sueldoMensual;
		public String rango;
		
		public Maquinista(){
			this.nombreCompleto="Nombre sin especificar.";
			this.dni="DNI sin especificar.";
			this.sueldoMensual=0;
			this.rango="Rango del maquinista sin especificar.";
		}
		
		public Maquinista(String nombreCompleto, String dni, int sueldoMensual, String rango){
			this.nombreCompleto=nombreCompleto;
			this.dni=dni;
			this.sueldoMensual=sueldoMensual;
			this.rango=rango;
		}
	}
	
	public class Mecanico {
		public String nombreCompleto;
		public int tlfno;
		public String especialidad;
		
		public Mecanico(){
			this.nombreCompleto="Nombre sin especificar.";
			this.tlfno=0;
			this.especialidad="Especialidad sin especifrar.";
		}
		
		public  Mecanico(String nombreCompleto, int tlfno, String especialidad){
			this.nombreCompleto=nombreCompleto;
			this.tlfno=tlfno;
			this.especialidad=especialidad;
		}
	}
	
	public class JefeEstacion {
		public String nombreCompleto;
		public String dni;
		
		public JefeEstacion(){
			this.nombreCompleto="Nombre sin especificar.";
			this.dni="DNI sin especificar.";
		}
		
		public JefeEstacion(String nombreCompleto, String dni){
			this.nombreCompleto=nombreCompleto;
			this.dni=dni;
		}
	}
	
	public static void main(String[] args) {
		
	}
}
