package unidad4.tarea1;

public class CuentaCorriente {
    private double saldo;
    private double limiteDescubierto;
    public String nombre;
    String dni;
    public static Banco bancoCuenta; // Es estático porque lo dice el enunciado.
    
    public CuentaCorriente(String nombre, String dni) {
        this.saldo = 0;
        this.limiteDescubierto = -50;
        this.nombre = nombre;
        this.dni = dni;
        CuentaCorriente.bancoCuenta = null;
    }
    
    public CuentaCorriente(String nombre, String dni, Banco banco) {
        this.saldo = 0;
        this.limiteDescubierto = -50;
        this.nombre = nombre;
        this.dni = dni;
        CuentaCorriente.bancoCuenta = banco;
    }
    
    public void modificarBanco(Banco banco) {
    	CuentaCorriente.bancoCuenta=banco;
    }

    public boolean sacarDinero(double cantidad) {
        if (this.saldo - cantidad >= this.limiteDescubierto) {
            this.saldo -= cantidad;
            System.out.println("Operación exitosa: Has retirado "+cantidad+" euros.");
            System.out.println();
            return true;
        } else {
            System.out.println("Operación fallida: Saldo insuficiente.");
            System.out.println();
            return false;
        }
    }
    	
    public void ingresarDinero(double cantidad) {
        this.saldo += cantidad;
        System.out.println("Operación exitosa: Has ingresado " + cantidad + " euros.");
        System.out.println();
    }

    public void mostrarInformacion() {
        System.out.println("Titular: "+nombre+" (DNI: "+dni+")");
        System.out.println("Saldo actual: "+saldo+" euros");
        System.out.println("Límite de descubierto: "+-limiteDescubierto+" euros");
        if (bancoCuenta!=null) {
        	System.out.println("Banco vinculado: "+bancoCuenta.getNombre());
        	System.out.println("	Capital disponible: "+bancoCuenta.capital);
        	System.out.println("	Dirección: "+bancoCuenta.direccion);
        	System.out.println();
        }
        else {
        	System.out.println("La cuenta no está vinculada a ningún banco todavía.");
        	System.out.println();
        }
    }

    public static void main(String[] args) {
        CuentaCorriente cuenta1 = new CuentaCorriente("Daniel Vilar Martínez", "92572901K");
        CuentaCorriente cuenta2 = new CuentaCorriente("José Fortunati Ruiz", "92572901K");
        Banco banco1 = new Banco("SANTANDER", 50222);
        
        cuenta1.modificarBanco(banco1);
        cuenta1.mostrarInformacion();
        banco1.setDireccion("Avenida de Andalucía, 13");
        cuenta1.ingresarDinero(1000);
        cuenta2.mostrarInformacion();
        
        /*cuenta.mostrarInformacion();
        cuenta.sacarDinero(500);
        cuenta.mostrarInformacion();
        cuenta.sacarDinero(80);
        cuenta.mostrarInformacion();*/
    }
    
    // Otra actividad:
    
    /*public CuentaCorriente(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public CuentaCorriente(double saldoInicial, double limiteDescubierto, String dni) {
        this.saldo = saldoInicial;
        this.limiteDescubierto = limiteDescubierto;
        this.dni = dni;
    }*/
   
}
