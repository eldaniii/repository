package unidad4.tarea1;

public class Maquinaria {
	class Vagon {
		int capacidadMax;
		int capacidadActual;
		String tipoMercancia;
		
		Vagon(){
			this.capacidadMax=5000;
			this.capacidadActual=0;
			this.tipoMercancia="Sin especificar.";
		}
		
		Vagon(int capacidadMax, int capacidadActual, String tipoMercancia){
			this.capacidadMax=capacidadMax;
			this.capacidadActual=capacidadActual;
			this.tipoMercancia=tipoMercancia;
		}
	}
	
	public class Locomotora {
		public String matricula;
		public int potenciaMotor;
		public int anoFabricacion;
		public Personal.Mecanico mecanico;
		
		public Locomotora(){
			this.matricula="Sin matricula registrada.";
			this.potenciaMotor=0;
			this.anoFabricacion=0;
			this.mecanico=null;
		}
		
		public Locomotora(String matricula, int potenciaMotor, int anoFabricacion, Personal.Mecanico mecanico) {
			this.matricula=matricula;
			this.potenciaMotor=potenciaMotor;
			this.anoFabricacion=anoFabricacion;
			this.mecanico=mecanico;
		}
	}
	
	public class Tren {
		public Locomotora locomotora;
		public Personal.Maquinista maquinista;
		public Vagon[] vagones = new Vagon[5];
		
		public Tren() {
			this.locomotora=null;
			this.maquinista=null;
		}
		
		public Tren(Locomotora locomotora, Personal.Maquinista maquinista) {
			this.locomotora = locomotora;
			this.maquinista = maquinista;
		}

		public void setVagones(Vagon[] vagones) {
			this.vagones = vagones;
		}
		
	}
}
