package unidad4.tarea1;

public class Texto {
	private StringBuffer cadena;
	private int longitudCadena;
	
	Texto(int longitudCadena){
		cadena = new StringBuffer(longitudCadena);
		this.longitudCadena = longitudCadena;
	}
	
	public void addChar(char c, String loc) {
		if (this.cadena.length()<this.longitudCadena) {
			if (loc.toLowerCase().contentEquals("final"))
				this.cadena.insert(cadena.length(), c);
			if (loc.toLowerCase().contentEquals("inicio"))
				this.cadena.insert(0, c);
		} else System.out.println("No queda espacio para añadir el carácter.");
	}
	
	public void addString(String s, String loc) {
		if (this.cadena.length()+s.length()<=this.longitudCadena) {
			if (loc.toLowerCase().contentEquals("final"))
				this.cadena.insert(cadena.length(), s);
			if (loc.toLowerCase().contentEquals("inicio"))
				this.cadena.insert(0, s);
		} else System.out.println("No queda espacio para añadir la cadena.");
	}
	
	public int countVowels() {
		int numVocales = 0;
		for (int i=0; i<this.cadena.length(); i++) {
			char caracter = this.cadena.toString().toLowerCase().charAt(i);
			
			switch (caracter) {
			case 'a','e','i','o','u':
				numVocales++;
				break;
			default:
				break;
			}
		}
		return numVocales;
	}

	public static void main(String[] args) {
		Texto texto1 = new Texto(10);
		Texto texto2 = new Texto(50);
		
		texto1.addString("hola", "inicio");
		System.out.println("Texto 1: "+texto1.cadena);
		System.out.println("vocales: "+texto1.countVowels());
		texto1.addChar('a', "inicio");
		System.out.println("Texto 1: "+texto1.cadena);
		System.out.println("vocales: "+texto1.countVowels());
		texto1.addString("como", "inicio");
		System.out.println("Texto 1: "+texto1.cadena);
		System.out.println("vocales: "+texto1.countVowels());
		
		System.out.println("-------------------");
		
		texto2.addChar('a', "inicio");
		System.out.println("Texto 2: "+texto2.cadena);
		System.out.println("vocales: "+texto2.countVowels());
		texto2.addString("ver primico trae paca", "final");
		System.out.println("Texto 2: "+texto2.cadena);
		System.out.println("vocales: "+texto2.countVowels());
	}
}
