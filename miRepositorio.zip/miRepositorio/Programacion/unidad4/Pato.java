package unidad4;

public class Pato extends Ave{
	Pato(){
		super(); //Usamos constructor del padre
	}
	
	@Override
	public void comunicarse() {
		System.out.println("Cuack cuack!");
	}
}
