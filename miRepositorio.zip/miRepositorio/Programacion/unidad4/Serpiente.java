package unidad4;

public class Serpiente extends Reptil {
	public enum Especies {COBRA, PITON, VIBORA;}
	
	Serpiente() {
		super();
	}
	
	public void comunicarse() {
		System.out.println("Sss sss!");
	}
	
	public void morder(Especies especie) {
		System.out.println("Me ha mordido una serpiente!");
		if (especie==Especies.COBRA) {
			this.muere();
		}
	}
	
	public static void muestraEspecies() {
		for (Especies esp: Especies.values()) {
			System.out.println(esp.toString()+" - ");
		}
		System.out.println();
	}
}
