package unidad4;

public abstract class Viviparo extends Animal{
	static int especimenes=0;
	
	Viviparo() {
		especimenes++;
	}
	
	public void reproducirse() {
		System.out.println("Reproduciendose (vivíparo)!");
	}
	
	public static void getVidas() {
		System.out.println("Vivíparos creados: "+especimenes);
	}
}
