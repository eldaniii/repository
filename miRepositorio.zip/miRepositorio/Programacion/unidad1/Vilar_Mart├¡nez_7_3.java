package unidad1;

public class Vilar_Martínez_7_3 {
	public static void main(String[] args) {
		int num = (int) Math.floor((Math.random()*(122-97))+97);
		char letter = (char) num;
		System.out.println(letter);
	}
}

