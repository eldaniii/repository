package unidad1;

public class MiClase {
	public static void main(String[] args) {
		String miNombre="Daniel";
		System.out.println("Hola");
		System.out.println(miNombre);
	}
}
