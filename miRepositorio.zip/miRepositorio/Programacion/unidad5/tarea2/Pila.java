package unidad5.tarea2;

public interface Pila {

}
