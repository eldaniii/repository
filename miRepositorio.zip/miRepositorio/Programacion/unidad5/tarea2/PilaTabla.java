package unidad5.tarea2;

public class PilaTabla implements Pila{

}
