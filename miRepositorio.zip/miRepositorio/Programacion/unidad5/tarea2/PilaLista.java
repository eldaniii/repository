package unidad5.tarea2;

public class PilaLista implements Pila{

}
