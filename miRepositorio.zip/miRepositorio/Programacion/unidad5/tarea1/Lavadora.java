package unidad5.tarea1;

public class Lavadora extends Electrodomestico {
	double carga=5;
	
	Lavadora() {
		super();
	}
	
	Lavadora(double precioBase, double peso) {
		super();
		this.precioBase=precioBase;
		this.peso=peso;
	}
	
	Lavadora(double carga) {
		super();
		this.carga=carga;
	}
	
	@Override
	public double getPrecioFinal() {
		double precioFinal = precioBase;
		
		switch(this.consumoEnerg) {
		case A: precioFinal+=100;
			break;
		case B: precioFinal+=80;
			break;
		case C: precioFinal+=60;
			break;
		case D: precioFinal+=50;
			break;
		case E: precioFinal+=30;
			break;
		case F: precioFinal+=10;
			break;
		}
		
		if (peso>=0 && peso<=29) precioFinal+=10;
		else if (peso>=30 && peso<=49) precioFinal+=60;
		else if (peso>=50 && peso<=79) precioFinal+=80;
		else if (peso>=80) precioFinal+=100;
		else if (carga>30) precioFinal+=50;
		
		return precioFinal;
	}
	
	@Override
	public String toString() {
		return null;
	}
	
	public double getCarga() {
		return carga;
	}
}
