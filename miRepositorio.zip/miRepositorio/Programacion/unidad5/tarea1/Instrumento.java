package unidad5.tarea1;

public abstract class Instrumento {
	protected static final int TAM_MAX = 100;
	public enum notasMusicales{DO, RE, MI, FA, SOL, LA, SI;}
	protected static notasMusicales[] notasMusicales = new notasMusicales[TAM_MAX];
	protected static int contadorNotas = 0;
	
	public static void add(notasMusicales nota) {
		if (contadorNotas < TAM_MAX) {
			Instrumento.notasMusicales[contadorNotas++] = nota;
		} else {
			System.out.println("No se pueden añadir más notas.");
		}
	}
	
	public abstract void interpretar();
}
