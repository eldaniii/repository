package unidad5.tarea1;

public class Electrodomestico {
	public enum COLORES{BLANCO, NEGRO, ROJO, AZUL, GRIS}
	public enum CONSUMO{A, B, C, D, E, F}
	COLORES color=COLORES.BLANCO;
	CONSUMO consumoEnerg=CONSUMO.F;
	double precioBase=100;
	double peso=5;
	
	Electrodomestico(){
		
	}
	
	Electrodomestico(double precioBase, double peso){
		this.color=COLORES.BLANCO;
		this.consumoEnerg=CONSUMO.F;
		this.precioBase=precioBase;
		this.peso=peso;
	}
	
	Electrodomestico(double precioBase, double peso, CONSUMO consumoEnerg, COLORES color){
		this.color=color;
		this.consumoEnerg=CONSUMO.F;
		this.precioBase=precioBase;
		this.peso=peso;
	}
	
	public double getPrecioFinal() {
		double precioFinal = precioBase;
		
		switch(this.consumoEnerg) {
		case A: precioFinal+=100;
			break;
		case B: precioFinal+=80;
			break;
		case C: precioFinal+=60;
			break;
		case D: precioFinal+=50;
			break;
		case E: precioFinal+=30;
			break;
		case F: precioFinal+=10;
			break;
		default:
			break;
		}
		
		if (peso>=0 && peso<=29) precioFinal+=10;
		else if (peso>=30 && peso<=49) precioFinal+=60;
		else if (peso>=50 && peso<=79) precioFinal+=80;
		else if (peso>=80) precioFinal+=100;
		
		return precioFinal;
	}
	
	@Override
	public String toString() {
		return "\nCARACTERÍSTICAS\n"
				+"Color: "+color+"\n"
				+"Consumo energético: "+consumoEnerg+"\n"
				+"Peso: "+peso+"\n"
				+"Precio base: "+precioBase+"\n"
				+"Precio final: "+getPrecioFinal();
	}

	public COLORES getColor() {
		return color;
	}

	public double getPrecioBase() {
		return precioBase;
	}

	public CONSUMO getConsumoEnergetico() {
		return consumoEnerg;
	}

	public double getPeso() {
		return peso;
	}
}
