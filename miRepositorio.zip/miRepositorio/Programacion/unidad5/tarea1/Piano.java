package unidad5.tarea1;

public class Piano extends Instrumento {

	@Override
	public void interpretar() {
		System.out.println("En el piano se escucha:");
		for (int i = 0; i < contadorNotas; i++) {
			System.out.println(notasMusicales[i] + " ");
		}
		System.out.println();
	}
}
