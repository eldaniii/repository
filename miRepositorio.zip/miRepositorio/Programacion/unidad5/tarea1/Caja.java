package unidad5.tarea1;

import unidad4.tarea1.Unidades;
import unidad4.tarea1.Unidades.uLongitud;

public class Caja implements Unidades {
	private final double ANCHO;
	private final double ALTO;
	private final double FONDO;
	private Unidades.uLongitud unidades;
	
	Caja(double ancho, double alto, double fondo, Unidades.uLongitud u){
		this.ANCHO=ancho;
		this.ALTO=alto;
		this.FONDO=fondo;
		this.unidades=u;
	}
	
	public double getVolumen(){
		double volumen = this.ANCHO*this.ALTO*this.FONDO;
		
		switch (this.unidades) {
		case M: 
			break;	
		case CM: volumen=volumen/1000000;
			break;
		default:
			break;
		}
		return volumen;
	}
	
	@Override
	public String toString() {
		String cadenaTotal = "\nMEDIDAS CAJA:\n ANCHO: "+this.ANCHO+"\n ALTO: "+this.ALTO+"\n FONDO: "+this.FONDO+" ("+this.unidades+")";
		return cadenaTotal;
	}
}
