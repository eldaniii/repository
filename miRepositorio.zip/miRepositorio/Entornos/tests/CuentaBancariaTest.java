package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.CuentaBancaria;

//Daniel Vilar Martínez 1ºDAW Mañana

class CuentaBancariaTest {
	private CuentaBancaria cuenta;
	
	@BeforeAll
	static void initAll() {
		System.out.println("Inicializando recursos antes de todas las pruebas.");
	}
	
	@BeforeEach
	void init() {
		cuenta=new CuentaBancaria(100.0); 
	}
	
	@Test
	@DisplayName("Comprobación del mensaje de error al intentar crear una cuenta con saldo negativo.")
	void comprobarSaldoInicialNegativo() {
		Exception exception=assertThrows(IllegalArgumentException.class,()->{
			cuenta=new CuentaBancaria(-50.0);
		});
		assertEquals("El saldo inicial no puede ser negativo.", exception.getMessage());
	}
	
	@Test
	@DisplayName("Comprobación que se crea una cuenta con saldo positivo.")
	void comprobarSaldoInicialPositivo() {
		double saldoActual=cuenta.getSaldo();
		assertEquals(100.0, saldoActual, "El saldo inicial no es correcto.");
	}
	
	@Test
	@DisplayName("Prueba a depositar una cantidad positiva.")
	void depositarCantidadPositiva() {
		double saldoActual=cuenta.depositar(50.0);
		assertEquals(150.0, saldoActual, "El saldo después del deposito no es correcto.");
	}
	
	@Test
	@DisplayName("Prueba a depositar una cantidad negativa.")
	void depositarCantidadNegativa() {
		Exception exception=assertThrows(IllegalArgumentException.class,()->{
			cuenta.depositar(-50.0);
		});
		assertEquals("La cantidad a depositar debe ser positiva.", exception.getMessage());
	}
	
	@Test
	@DisplayName("Prueba a depositar una cantidad cero.")
	void depositarCantidadCero() {
		Exception exception=assertThrows(IllegalArgumentException.class,()->{
			cuenta.depositar(0.0);
		});
		assertEquals("La cantidad a depositar debe ser positiva.", exception.getMessage());
	}
	
	@Test
	@DisplayName("Prueba a retirar una cantidad positiva con saldo suficiente.")
	void retirarCantidadPositivaConSaldoSuficiente() {
		double saldoActual=cuenta.retirar(50.0);
		assertEquals(50.0, saldoActual, "El saldo después del retiro no es correcto.");
	}
	
	@Test
	@DisplayName("Prueba a retirar una cantidad positiva con saldo insuficiente.")
	void retirarCantidadPositivaConSaldoInsuficiente() {
		Exception exception=assertThrows(IllegalArgumentException.class,()->{
			cuenta.retirar(150.0);
		});
		assertEquals("Fondos insuficientes para retirar.", exception.getMessage());
	}
	
	@Test
	@DisplayName("Prueba a retirar una cantidad negativa.")
	void retirarCantidadNegativa() {
		Exception exception=assertThrows(IllegalArgumentException.class,()->{
			cuenta.retirar(-50.0);
		});
		assertEquals("La cantidad a retirar debe ser positiva.", exception.getMessage());
	}
	
	@Test
	@DisplayName("Prueba a retirar una cantidad cero.")
	void retirarCantidadCero() {
		Exception exception=assertThrows(IllegalArgumentException.class,()->{
			cuenta.retirar(0.0);
		});
		assertEquals("La cantidad a retirar debe ser positiva.", exception.getMessage());
	}
	
	@Test
	@DisplayName("Comprobación de que la cuenta devuelve el saldo correcto.")
	void comprobarSaldo() {
		cuenta.depositar(88.0);
		cuenta.retirar(50.0);
		double saldoActual=cuenta.getSaldo();
		assertEquals(138.0, saldoActual, "El saldo de la cuenta no es el correcto.");
	}
}
