package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.Calculadora;

// Daniel Vilar Martínez 1ºDAW Mañana

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CalculadoraTest {
	@Test
	@DisplayName("Prueba sumar dos números positivos")
	void pruebaSumarPositivos() {
		double valorEsperado = 30;
		Calculadora calcu = new Calculadora(20,10);
		double resultado = calcu.suma();
		assertEquals(valorEsperado, resultado, "Mensaje de error.");
	}
	
	@Test
	@DisplayName("Prueba restar dos números positivos")
	void pruebaRestarPositivos() {
		double valorEsperado = 10;
		Calculadora calcu = new Calculadora(20,10);
		double resultado = calcu.resta();
		assertEquals(valorEsperado, resultado, "Mensaje de error.");
	}
	
	@Test
	@DisplayName("Prueba a multiplicar dos números positivos")
	void pruebaMultiplicaPositivos() {
		double valorEsperado = 200;
		Calculadora calcu = new Calculadora(20,10);
		double resultado = calcu.multiplica();
		assertEquals(valorEsperado, resultado, "Mensaje de error.");
	}
	
	@Test
	@DisplayName("Prueba al dividir un número entre 0")
	void pruebaDividir0() {
		try {
			Calculadora calc = new Calculadora(20, 0);
			calc.divide();
			fail("Debe saltar la excepción");
		}catch(Exception e) {
			
		}
	}
	
	@Test
	@DisplayName("Comprueba el mensaje de error esperado al dividir un número entre 0")
	void pruebaDividir0MensajeException() {
		String mensajeEsperado="División por 0";
		Calculadora calcu  = new Calculadora(20,0);
		Exception exception = assertThrows(ArithmeticException.class, () -> calcu.divide0());
		assertEquals(mensajeEsperado, exception.getMessage());
	}
	
	@ParameterizedTest
	@ValueSource(strings = {"Hola", "Mundo"})
	void test(String mensaje) {
		System.out.println(mensaje);
		assertNotNull(mensaje);
	}
	
	@ParameterizedTest
	@ValueSource(ints = {1,2,3,4,5})
	void prueba_Parameterized_enteros(int numero) {
		assertTrue(numero>0);
	}
	
	@ParameterizedTest
	@MethodSource(value = "get_nombres")
	void prueba_2_paramerized(String nombres) {
		System.out.println("2>"+nombres);
		assertTrue(nombres.length()>3);
	}
	
	List<String> get_nombres() {
		return Arrays.asList("Hola", "Mundo");
	}
	
	@ParameterizedTest
	@CsvSource({"10, 2, 5",
				"30, -2, -15",
				"8, 4, 2"
	})
	void divide_varios_parametros(int a, int b, int valor_esperado) {
		Calculadora calc = new Calculadora(a, b);
		assertEquals(valor_esperado, calc.divide(), "No es divisible");
	}
	
	@ParameterizedTest
	@CsvSource({"5, 2, 10",
			"15, 3, 45",
			"8, 2, 16"
	})
	void multiplica_varios_parametros(int a, int b, int valor_esperado) {
		Calculadora calc = new Calculadora(a, b);
		assertEquals(valor_esperado, calc.multiplica(), "Mensaje de error multiplicación");
	}
 }
